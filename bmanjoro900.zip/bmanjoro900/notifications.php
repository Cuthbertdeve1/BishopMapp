<!DOCTYPE html>
<html lang="en-US">
<head>
<title>notifications</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />




 <link rel="stylesheet" type="text/css" href="alpages.css">
	<link rel="stylesheet" href="jquery mobile 1.4.5/css1/jquery.mobile-1.4.5.min.css">
	<link rel="stylesheet" href="jquery mobile 1.4.5/css1/jqm-demos.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<script src="jquery mobile 1.4.5/js/jquery.js"></script>
	<script src="jquery mobile 1.4.5/js2/index.js"></script>
	<script src="jquery mobile 1.4.5/js/jquery.mobile-1.4.5.min.js"></script>
	
</head>
<body>

<div data-role="page" class="jqm-demos jqm-home" style="background-color:#000000">

  
  <div data-role="header" class="jqm-header">
		<h2><a href="index.html"><img src="APP/informationL.png" width="30%" height="auto" alt="Bishop Manjoro Ministries"></a></h2>
		<p>FWM_App</p>
		<a href="#" class="jqm-navmenu-link ui-btn ui-btn-icon-notext ui-corner-all ui-icon-bars ui-nodisc-icon ui-alt-icon ui-btn-left">Menu</a>
	
	</div><!-- /header -->
	<div role="main" class="ui-content jqm-content">
	<h1 style="color:#ffff66">Bishop Ministry Work's</h1>
    <section>

           <img src="APP/mainp.jpg" width="100%"; height="30%"></img>
  </section>

<div id="note">
	<p maxlength="300" cols="100%" rows="10%" name="text" required>
		<?php
		$filename ='faith world admin potal/notifications.txt';
		$handle =fopen($filename, 'r');
		
		
		
		echo fread( $handle,1000);

		?>
		
	</p>
</div>
    </div><!-- /content -->

	    <div data-role="panel" class="jqm-navmenu-panel" data-position="left" data-display="overlay" data-theme="a">
	    	<ul class="jqm-list ui-alt-icon ui-nodisc-icon">
<li data-icon="home"><a href="index.html">Home</a></li>
<li data-icon="calendar"><a href="conferance.html" data-ajax="false">Events</a></li>
<li data-icon="grid"><a href="bible_college.html" data-ajax="false">Bible College</a></li>
<li data-icon="edit" ><a href="prayer_request.php" data-ajax="false">Prayer Request</a></li>
<li data-icon="info" ><a href="itinerary.html" data-ajax="false">Itinerary</a></li>
<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
		    About The Bishop<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
			<li data-icon="user"><a href="about_bishop.html" data-ajax="false">Bishop Manjoro</a></li>
			<li data-icon="info" ><a href="about_work and achivements.html" data-ajax="false">Work's And Achivements</a></li>
		</ul>
	</div>
</li>
<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
			The Bishop's Familly<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
		<li data-icon="user"><a href="about_bishop.html" data-ajax="false">Bishop</a></li>
		 <li data-icon="user"><a href="doctor_junr.html" data-ajax="false">Dr Junior</a></li>
			<li data-icon="user"><a href="rev.html" data-ajax="false">Rev Mutibvu</a></li>
			<li data-icon="user"><a href="pastor_eloi.html" data-ajax="false">Pastor Eloi</a></li>
		</ul>
	</div>
</li>





<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
			Media<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
			<li data-icon="video"><a href="videos.html" data-ajax="false">Videos</a></li>
           <li data-icon="audio" ><a href="audio.php" data-ajax="false">Audio</a></li>
		</ul>
	</div>
</li>
<li data-icon="mail"><a href="follow_us.html" data-ajax="false">Follow Us</a></li>


		     </ul>
		</div><!-- /panel -->

    <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
		 <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="https://www.facebook.com/BishopDr.B.Manjoro/"><img src="APP/fb.png" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="https://twitter.com/intent/follow?original_referer=http%3A%2F%2Fbishopmanjoro.org%2Ffwm%2Findex.php&ref_src=twsrc%5Etfw&screen_name=bishopmanjoro&tw_p=followbutton">  <img src="APP/twitter.png" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="https://www.youtube.com/results?search_query=bishop+manjoro"> <img src="APP/yutube.png" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
	
	</div><!-- /footer -->
 </div><!-- /page -->
</body>
</html>