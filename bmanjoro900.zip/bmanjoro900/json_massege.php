<?php
header("Content-Type: application/json");
//$folder =$_POST["folder"];
$folder = "messagesF";
$jsonData ='{';
$dir= $folder."/";
$dirHandle = opendir($dir);

while ($file = readdir($dirHandle)){
	$i = 0;
	//$limit =preg_replace('#[^0-9 a-z]#i','', $_POST['limit']);
	if(!is_dir($file) && preg_replace('#[^0-9 a-z]#i','',$file)){
		$i++;
		$src="$dir$file";
		$jsonData .='"note'.$i.'":{"num":"'.$i.'","src":"'.$src.'","name":"'.$file.'"},';
		
	}
}
closedir($dirHandle);
$jsonData=chop($jsonData,",");

$jsonData .='}';
echo fread ($jsonData,1000);
?>

$filename ='faith world admin potal/notifications.txt';
		$handle =fopen($filename, 'r');