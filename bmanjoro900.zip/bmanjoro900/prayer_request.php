<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>bishops app</title>
	

<!-- jQuery -->
<script type="text/javascript" src="pagesMenu/src/libs/jquery/jquery.js"></script>

<!-- SmartMenus jQuery plugin -->
<script type="text/javascript" src="pagesMenu/jquery.smartmenus.js"></script>


<script type="text/javascript">
	$(function() {
		$('#main-menu').smartmenus({
			subMenusSubOffsetX: 1,
			subMenusSubOffsetY: -8
		});
	});
</script>


<link rel="stylesheet" type="text/css" href="alpages.css">


<link rel="stylesheet" href="jquery mobile 1.4.5/css1/jquery.mobile-1.4.5.min.css">
	<link rel="stylesheet" href="jquery mobile 1.4.5/css1/jqm-demos.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<script src="jquery mobile 1.4.5/js/jquery.js"></script>
	<script src="jquery mobile 1.4.5/js2/index.js"></script>
	<script src="jquery mobile 1.4.5/js/jquery.mobile-1.4.5.min.js"></script>

</head>
<body>
<div data-role="page" class="jqm-demos jqm-home" style="background-color:#000000;color:white;">
<?php
   if(isset($_POST['username']) && isset($_POST['email']) &&isset($_POST['phone']) &&isset($_POST['comments'])){
	   $username =$_POST['username'];
	   $email =$_POST['email'];
	   $phone =$_POST['phone'];
	   $comments =$_POST['comments'];
	   
	   if(!empty($username) && !empty($email) && !empty($phone)&& !empty($comments)){
		   $to = 'cartbertkurangana@gmail.com';
		   $subject = 'Prayer request submitted.';
		   $body = $username."\n".$comments;
		   $headers ='From:'.$email;
		   ?>
		   <h1><?php
		   echo'request send thank you';
	   }else{
		   echo'All fields are required';
	   }
   }
  
  ?>
</h1>
<header width="100%;"height="100%;">
<div data-role="header" class="jqm-header">
<h2><a href="index.html"><img src="APP/logo.png" width="30%" height="auto" alt="Bishop Manjoro Ministries"></a></h2>
		<p>FWM_App</p>
		<a href="#" class="jqm-navmenu-link ui-btn ui-btn-icon-notext ui-corner-all ui-icon-bars ui-nodisc-icon ui-alt-icon ui-btn-left">Menu</a>
	
	
</div><!-- /header -->
</header>
<div role="main" class="ui-content jqm-content">

<h1>Prayer Request</h1>
<section>
   <div id="my_pics">

              <div id="bishops"><img src="APP/mainp.jpg" width="100%" height="30%"
			  ></img></div>
               
      
  </div>
  </section>
<article>

    <div style="text-align:center">
	     
	      <h2 style="text-align:center; margin-bottom:20px;">Not Functioning For Now!!</h2>
		     <form method="POST" action="prayer_request.php">
	<span class="labelName">Enter You Name:</span> <input type="text" name="username" id="name" maxlength="40" title="you name" required><br>
	<span class="labelEmail">Enter You Email:</span><input type="email" name="email"><br>
  <p style="margin-bottom:20px"> <span class="labelPhone">Enter Phone Number</span><input type="tel" name="phone" maxlength="15" required><br /></p>
  <p style="width:120%"><textarea name="comments" required cols="20" rows="6" maxlength="500" title="request"></textarea><br /></p>
 
 
 <a class="ui-btn ui-btn-inline" href="#">Reset</a>
 <button  input="type:reset" class="ui-btn ui-btn-inline">Send</button>

  </form>		           
  </div>   
	
</article>
</div><!-- /content -->
    <div data-role="panel" class="jqm-navmenu-panel" data-position="left" data-display="overlay" data-theme="a">
	    	<ul class="jqm-list ui-alt-icon ui-nodisc-icon">
<li data-icon="home"><a href="index.html">Home</a></li>
<!--<li data-icon="calendar"><a href="conferance.html" data-ajax="false">Events</a></li>-->
<li data-icon="grid"><a href="bible_college.html" data-ajax="false">Bible College</a></li>
<li data-icon="edit" ><a href="prayer_request.php" data-ajax="false">Prayer Request</a></li>
<!--<li data-icon="info" ><a href="about_work and achivements.html" data-ajax="false">Bishop's works and Achivments</a></li>-->
<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
		    About The Bishop<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
			<li data-icon="user"><a href="about_work and achivements.html" data-ajax="false">Bishop Manjoro</a></li>
			<li data-icon="info" ><a href="bishop's ministry _works.html" data-ajax="false">Work's And Achivements</a></li>
		</ul>
	</div>
</li>
<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
			The Bishop's Familly<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
		<li data-icon="user"><a href="about_bishops family.html" data-ajax="false">Bishop</a></li>
		 <li data-icon="user"><a href="doctor_junr.html" data-ajax="false">Dr Junior</a></li>
			<li data-icon="user"><a href="rev.html" data-ajax="false">Rev Mutibvu</a></li>
			<li data-icon="user"><a href="pastor_eloi.html" data-ajax="false">Pastor Eloi</a></li>
		</ul>
	</div>
</li>





<li data-role="collapsible" data-enhanced="true" data-collapsed-icon="carat-d" data-expanded-icon="carat-u" data-iconpos="right" data-inset="false" class="ui-collapsible ui-collapsible-themed-content ui-collapsible-collapsed">
	<h3 class="ui-collapsible-heading ui-collapsible-heading-collapsed">
		<a href="#" class="ui-collapsible-heading-toggle ui-btn ui-btn-icon-right ui-btn-inherit ui-icon-carat-d">
			Media<span class="ui-collapsible-heading-status"> click to expand contents</span>
		</a>
	</h3>
	<div class="ui-collapsible-content ui-body-inherit ui-collapsible-content-collapsed" aria-hidden="true">
		<ul>
			<li data-icon="video"><a href="videos.html" data-ajax="false">Videos</a></li>
           <li data-icon="audio" ><a href="audio.html" data-ajax="false">Audio</a></li>
		</ul>
	</div>
</li>
<!--<li data-icon="mail"><a href="follow_us.html" data-ajax="false">Follow Us</a></li>-->


		     </ul>
		</div><!-- /panel -->

 <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="https://www.facebook.com/BishopDr.B.Manjoro/"><img src="APP/fb.png" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="https://twitter.com/intent/follow?original_referer=http%3A%2F%2Fbishopmanjoro.org%2Ffwm%2Findex.php&ref_src=twsrc%5Etfw&screen_name=bishopmanjoro&tw_p=followbutton">  <img src="APP/twitter.png" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="https://www.youtube.com/results?search_query=bishop+manjoro"> <img src="APP/yutube.png" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
 </div><!-- /page -->
</body>

</html>