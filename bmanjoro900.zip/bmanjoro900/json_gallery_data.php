<?php
header("Content-Type: application/json");
$folder =$_POST["folder"];
//$folder = "videos";
$jsonData ='{';
$dir = $folder."/";
$dirHandle = opendir($dir);
$i = 0;
while ($file = readdir($dirHandle)){
	if(!is_dir($file) && preg_match("/.mp4|.avi/i",$file)){
		$i++;
		$src="$dir$file";
		$jsonData .='"vid'.$i.'":{"num":"'.$i.'","src":"'.$src.'","name":"'.$file.'"},';
		
	}
}
closedir($dirHandle);
$jsonData=chop($jsonData,",");
//$jsonData .='"gallerydetails":{"piccount":'.$i.'}';
$jsonData .='}';
echo $jsonData;
?>